import React, { useState } from "react";
import { generateAIResponse } from "../Openai";

export default function Chatbot() {
  const [messages, setMessages] = useState([
    { role: "assistant", content: "Hello! How can I help you grow today?" }
  ]);

  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  const sendMessage = async () => {
    if (!input.trim()) return;

    const newMessages = [...messages, { role: "user", content: input }];
    setMessages(newMessages);
    setInput("");
    setLoading(true);

    const reply = await generateAIResponse(input, newMessages);
    setMessages([...newMessages, { role: "assistant", content: reply }]);

    setLoading(false);
  };

  return (
    <div style={{ width: "100%", padding: "20px" }}>
      {/* Messages */}
      <div
        style={{
          height: "380px",
          overflowY: "auto",
          marginBottom: "15px",
          padding: "10px",
          background: "rgba(255,255,255,0.05)",
          borderRadius: "12px",
          backdropFilter: "blur(8px)",
        }}
      >
        {messages.map((msg, i) => (
          <div
            key={i}
            style={{
              margin: "10px 0",
              padding: "12px",
              borderRadius: "10px",
              background: msg.role === "assistant" ? "#6b46c1" : "#1f1f1f",
              color: "white",
              maxWidth: "80%",
              alignSelf: msg.role === "user" ? "flex-end" : "flex-start",
            }}
          >
            {msg.content}
          </div>
        ))}
      </div>

      {/* Input */}
      <div style={{ display: "flex", gap: "10px" }}>
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask something..."
          style={{
            flex: 1,
            padding: "12px",
            borderRadius: "10px",
            border: "1px solid #444",
            background: "#121212",
            color: "white",
          }}
        />
        <button
          onClick={sendMessage}
          disabled={loading}
          style={{
            padding: "12px 16px",
            borderRadius: "10px",
            background: "#7c3aed",
            color: "white",
            cursor: "pointer",
          }}
        >
          {loading ? "..." : "Send"}
        </button>
      </div>
    </div>
  );
}