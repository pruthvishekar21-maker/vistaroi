export default function Terms() {
  return (
    <div className="min-h-screen bg-black text-white p-10 max-w-3xl mx-auto">
      <h1 className="text-4xl font-bold mb-6">Terms of Use</h1>
      <p className="text-gray-300">
        By using Vistaroi, you agree to use the platform ethically and not
        misuse or attempt to reverse engineer any systems. Subscription fees are
        billed monthly and must be renewed to maintain access.
      </p>
    </div>
  );
}