export default function Policy() {
  return (
    <div className="min-h-screen bg-black text-white p-10 max-w-3xl mx-auto">
      <h1 className="text-4xl font-bold mb-6">Privacy Policy</h1>
      <p className="text-gray-300">
        Vistaroi (“we”, “our”, “us”) collects business data to generate insights
        and recommendations. We do not sell or misuse your information.
        Authentication is securely managed using Firebase and payments are
        processed through trusted partners.
      </p>
    </div>
  );
}