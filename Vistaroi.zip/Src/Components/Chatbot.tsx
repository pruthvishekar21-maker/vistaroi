import { useState } from "react";
import { generateAIResponse } from "../OpenAI";

export default function Chatbot() {
  const [input, setInput] = useState("");
  const [conversation, setConversation] = useState<{ role: string; content: string }[]>([]);
  const [loading, setLoading] = useState(false);

  async function sendMessage() {
    if (!input.trim()) return;

    const userMessage = { role: "user", content: input };
    const updatedHistory = [...conversation, userMessage];

    setConversation(updatedHistory);
    setInput("");
    setLoading(true);

    try {
      const aiReply = await generateAIResponse(input, updatedHistory);
      setConversation((prev) => [...prev, { role: "assistant", content: aiReply }]);
    } catch (err) {
      setConversation((prev) => [
        ...prev,
        { role: "assistant", content: "⚠️ AI service unavailable. Please try again." }
      ]);
    }

    setLoading(false);
  }

  return (
    <div className="p-6 max-w-3xl mx-auto text-white">
      <h1 className="text-3xl font-bold mb-4">AI Strategizer</h1>

      <div className="space-y-4 max-h-[60vh] overflow-y-auto border rounded-lg p-4 bg-black/40 backdrop-blur">
        {conversation.map((msg, idx) => (
          <div key={idx} className={msg.role === "user" ? "text-purple-300" : "text-yellow-300"}>
            <strong>{msg.role === "user" ? "You:" : "AI:"}</strong> {msg.content}
          </div>
        ))}
        {loading && <div className="text-gray-400">Thinking...</div>}
      </div>

      <div className="mt-4 flex gap-2">
        <input
          className="flex-1 p-2 rounded bg-black/30 border border-purple-500 outline-none"
          placeholder="Ask Vistaroi anything..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
        />
        <button
          onClick={sendMessage}
          className="px-4 py-2 bg-purple-600 hover:bg-purple-700 rounded text-white"
        >
          Send
        </button>
      </div>
    </div>
  );
}