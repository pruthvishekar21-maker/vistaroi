/**
 * src/openai.ts
 * * Service layer for interacting with the OpenAI API for Vistaroi's AI Strategist.
 */
import OpenAI from "openai";

const hasOpenAIKey = !!process.env.OPENAI_API_KEY;

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
console.log("Has key:", !!process.env.OPENAI_API_KEY);

// 🔑 Code Fix: Ensure that `process.env.OPENAI_API_KEY` is always a string when passed to OpenAI.
const openai = hasOpenAIKey ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY as string }) : null;

/**
 * Generates a strategic response from the AI based on user input and conversation history.
 * @param userMessage - The latest message from the user.
 * @param conversationHistory - The prior messages in the conversation (role and content).
 * @returns A promise that resolves to the AI's response text.
 */
export async function generateAIResponse(userMessage: string, conversationHistory: any[]): Promise<string> {
  if (!openai) {
    return "The AI Strategist requires an OpenAI API key to function. Please configure your API key in the environment settings.";
  }

  try {
    // 💡 Typing: Using a map for conversation history to ensure role is correctly typed
    const historyMessages = conversationHistory.map((msg: any) => ({
        role: msg.role as "user" | "assistant",
        content: msg.content
      }));

    const messages = [
      {
        role: "system" as const,
        content: `You are an expert AI Business Strategist for Vistaroi, a business intelligence platform. You help entrepreneurs and companies analyze their marketing data, optimize ROI, and develop growth strategies. 

Your responses should be:
- Actionable and specific
- Data-driven and analytical
- Focused on ROI optimization and business growth
- Professional yet approachable
- Concise but comprehensive

When discussing metrics, provide specific recommendations on:
- Budget allocation
- Campaign optimization
- Market targeting
- Performance improvements
- Growth opportunities`
      },
      ...historyMessages,
      {
        role: "user" as const,
        content: userMessage
      }
    ];

    const response = await openai.chat.completions.create({
      model: "gpt-5-mini",
      messages,
      max_completion_tokens: 8000,
    });

    return response.choices[0].message.content || "I apologize, but I couldn't generate a response. Please try again.";
  } catch (error) {
    console.error("Error generating AI response:", error);
    // 🔑 Error Handling Fix: Re-throw a generic error to be caught by a calling service/component.
    throw new Error("Failed to generate AI response");
  }
}

/**
 * Generates a specific, actionable business insight based on the provided metrics data.
 * @param metricsData - An object containing key business metrics.
 * @returns A promise resolving to an insight object with title, description, and priority.
 */
export async function generateBusinessInsight(metricsData: any): Promise<{ title: string; description: string; priority: string }> {
  if (!openai) {
    return {
      title: "Performance Review",
      description: "Continue monitoring your metrics for growth opportunities.",
      priority: "medium",
    };
  }

  try {
    const prompt = `Based on the following business metrics, generate ONE specific, actionable insight:

Metrics: ${JSON.stringify(metricsData)}

Provide the insight in JSON format with:
- title: A short, impactful title (max 50 chars)
- description: A specific, actionable recommendation (max 150 chars)
- priority: "high", "medium", or "low"

Focus on ROI optimization, budget allocation, or growth opportunities.`;

    const response = await openai.chat.completions.create({
      model: "gpt-5-mini",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
      max_completion_tokens: 8000,
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return {
      title: result.title || "Business Insight",
      description: result.description || "Review your metrics for optimization opportunities.",
      priority: result.priority || "medium",
    };
  } catch (error) {
    console.error("Error generating business insight:", error);
    // 💡 Fallback: Return a soft-error insight instead of throwing to maintain UI stability
    return {
      title: "Insight Generation Failed",
      description: "Failed to process metrics. Check the server logs for details.",
      priority: "high", // Indicate a problem to the user
    };
  }
}
